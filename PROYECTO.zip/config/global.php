<?php 
//ip de la pc servidor base de datos
define("DB_HOST", "localhost");

// nombre de la base de datos
define("DB_NAME", "libertista");


//nombre de usuario de base de datos
define("DB_USERNAME", "admin");

//conraseña del usuario de base de datos
define("DB_PASSWORD", "123");

//codificacion de caracteres
define("DB_ENCODE", "utf8");

//nombre del proyecto
define("PRO_NOMBRE", "CompartiendoCodigos");
 
 ?> 