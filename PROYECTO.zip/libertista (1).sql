-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-11-2024 a las 22:24:44
-- Versión del servidor: 5.6.20
-- Versión de PHP: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `libertista`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumn`
--

CREATE TABLE IF NOT EXISTS `alumn` (
`id` int(11) NOT NULL,
  `image` varchar(50) COLLATE utf8_bin NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(50) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `address` varchar(60) COLLATE utf8_bin NOT NULL,
  `phone` varchar(60) COLLATE utf8_bin NOT NULL,
  `c1_fullname` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c1_address` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c1_phone` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c1_note` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c2_fullname` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c2_address` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c2_phone` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `c2_note` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=61 ;

--
-- Volcado de datos para la tabla `alumn`
--

INSERT INTO `alumn` (`id`, `image`, `name`, `lastname`, `email`, `address`, `phone`, `c1_fullname`, `c1_address`, `c1_phone`, `c1_note`, `c2_fullname`, `c2_address`, `c2_phone`, `c2_note`, `is_active`, `created_at`, `user_id`) VALUES
(1, '1730417691.png', 'ESTEBAN LEONARDO', 'BALLESTEROS CORREDOR', 'ballesteroscorredor.esteban@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(2, '1730417835.png', 'JHOAN JAVIER', 'MENDIVELSO LOZANO', 'mendivelsolozano.jhoan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(3, '1730417939.png', 'MARIA FERNANDA', 'SANDOVAL DUARTE', 'sandovalduarte.maria@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(4, '1730418108.png', 'MARIA ESMERALDA', 'BALLESTEROS CORREDOR', 'ballesteroscorredor.maria@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(5, '1730418371.png', 'SAMUEL CAMILO', 'FONSECA ANGEL', 'fonsecaangel.samuel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(6, '1730418493.png', 'ANGEL FABIAN', 'RIOS HERRERA', 'riosherrera.angel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(7, '1730418690.png', 'MONICA GISEL', 'AFRICANO RODRIGUEZ', 'africanorodriguez.monica@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(8, '1730418846.png', 'ANGEL DANIEL', 'GALINDO SOLER', 'galindosoler.daniel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(9, '1730418986.png', 'JHON DEYBIS', 'IBARRA CORREDOR', 'ibarracorredor.jhon@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(10, '1730419081.png', 'JUAN SEBASTIAN', 'RINCON CARDENAS', 'rinconcardenas.juan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(11, '1730421038.png', 'NICOLAS', 'ARAQUE ALFONSO', 'araquealfonso.nicolas@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(12, '1730421922.png', 'DANNA SOFIA', 'MESA ROJAS', 'mesarojas.danna@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(13, '1730422047.png', 'MICHELL DAYANA', 'SALAMANCA SILVA', 'salamancasilva.michell@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(14, '1730422101.png', 'MARIA JOSE', 'BECERRA BAUTISTA', 'becerrabautista.maria@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(15, '1730422193.png', 'JHONATAN', 'ORTIZ SANDOVAL', 'ortizsandoval.jhonatan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(16, '1730422275.png', 'ZAIRA SOFIA', 'VARGAS UNIBIO', 'vargasunibio.zaira@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(17, '1730422367.png', 'JONATHAN LEONARDO', 'ALBARRACIN ZORRO', 'albarracinzorro.jonathan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(18, '1730422479.png', 'EYDER SANTIAGO', 'CHAPARRO RIOS', 'chaparrorios.eyder@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(19, '1730422549.png', 'LAURA VALENTINA', 'PEREZ VALDERRAMA', 'perezvalderrama.laura@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(20, '1730422602.png', 'CRISTIAN DAVID', 'TEJEDOR SANDOVAL', 'tejedorsandoval.cristian@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(21, '1730422783.png', 'LAURA JOHANA', 'ANGEL MESA', 'angelmesa.laura@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(22, '1730422836.png', 'SHARIT JULIANA', 'REYES DUEÑES', 'reyesduenes.sharit@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(23, '1730423007.png', 'SAMUEL SANTIAGO', 'CARDENAS PONGUTA', 'cardenasponguta.samuel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(24, '1730423055.png', 'JOSE DAVID', 'UNDA CASTRO', 'undacastro.jose@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(25, '1730423631.png', 'TANIA NICOL', 'ALARCON GOMEZ', 'alarcongomez.tania@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(26, '1730423692.png', 'KEVIN LEONARDO', 'LONDOÑO SOCHA', 'londonosocha.kevin@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(27, '1730423739.png', 'PEDRO LUIS', 'VILLATE CEPEDA', 'villatecepeda.pedro@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(28, '1730424902.png', 'DIANA CAROLINA', 'BETANCOURT CHAPARRO', 'betancourtchaparro.diana@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(29, '1730425240.png', 'MIGUEL ANGEL', 'LOPEZ CHIA', 'lopezchia.miguel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(30, '1730425452.png', 'LAURA DANIELA', 'VANEGAS OCHOA', 'vanegasochoa.laura@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(31, '1730425674.png', 'EMANUEL SANTIAGO', 'CALDERON RIOS', 'calderonrios.emanuel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(32, '1730500632.png', 'DIANA LUCERO', 'LEON GIL', 'leongil.diana@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(33, '1730500700.png', 'HAROL STEVEN', 'SUAREZ ROJAS', 'suarezrojas.harol@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(34, '1730501272.png', 'CRISTIAN DAVID', 'CASTRO GOMEZ', 'castrogomez.cristian@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(35, '1730501379.png', 'ANDRES LEONARDO', 'PEREZ OCHOA', 'perezochoa.andres@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(36, '1730501460.png', 'SHARIT DANIELA', 'VARGAS RINCON', 'vargasrincon.sharit@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(37, '1730501519.png', 'LAURA ESTEFANIA', 'CASTELLANOS PIRACOCA', 'castellanospiracoca.laura@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(38, '1730501577.png', 'JUAN PABLO', 'PEREZ CRISPIN', 'perezcrispin.juan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(39, '1730501757.png', 'EDWIN MATEO', 'SALAMANCA ALVAREZ', 'salamancalavarez.edwin@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(40, '1730501805.png', 'NICOLAS ANDREY', 'SIABATO PEREZ', 'siabatoperez.nicolas@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(41, '1730501919.png', 'KEVIN SEBASTIAN', 'ALFONSO COTAMO', 'alfonsocotamo.kevin@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(42, '1730501975.png', 'DIANA MARIA', 'CADENA CORREDOR', 'cadenacorredor.diana@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(43, '1730502036.png', 'DAVID SANTIAGO', 'ESCOBAR GONZALEZ', 'escobargonzalez.david@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(44, '1730502114.png', 'ESTEBAN', 'PEREIRA GAMA', 'pereiragama.esteban@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(45, '1730502295.png', 'CAROLINA YISSETH', 'SILVA MURILLO', 'silvamurillo.carolina@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(46, '1730502341.png', 'MAYRA CELENY', 'ACEVEDO ACEVEDO', 'acevedo.mayra@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(47, '1730502414.png', 'VALENTINA', 'CORREDOR BERDUGO', 'corredorberdugo.valentina@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(48, '1730502503.png', 'DIEGO FERNANDO', 'GUTIERREZ ALVAREZ', 'gutierrezalvarez.diego@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(49, '1730502564.png', 'SAMUEL CAMILO', 'RAMOS TURIZO', 'ramosturizo.samuel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(50, '1730502621.png', 'CELENE ALEXANDRA', 'ZORRO PEREZ', 'zorroperez.celene@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(51, '1730502702.png', 'MIGUEL ANGEL', 'AMADO GUERRERO', 'amadoguerrero.miguel@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(52, '1730502757.png', 'ZHARICK JINETH', 'IBARRA SORACA', 'ibarrasoraca.zharick@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(53, '1730502829.png', 'NICOLAS ALEJANDRO', 'REYES DUEÑES', 'reyesduenes.nicolas@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(54, '1730502899.png', 'DEIVER JULIAN', 'SANABRIA BERDUGO', 'sanabriaberdugo.deiver@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(55, '1730502975.png', 'JHONATAN FERNEY', 'LARA CHAPARRO', 'larachaparro.jhonatan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(56, '1730503055.png', 'CRISTIAN CAMILO', 'RAMIREZ MERCHAN', 'ramirezmerchan.camilo@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(57, '1730503148.png', 'JOHANN SEBASTIAN', 'SALAZAR LOPEZ', 'salazarlopez.johann@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(58, '1730503224.png', 'JAVIER GIOVANNY', 'AGUILAR BONILLA', 'aguilarbonilla.javier@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(59, '1730503286.png', 'JUAN FELIPE', 'PEREIRA GAMA', 'pereiragama.juan@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1),
(60, '1730503348.png', 'LAURA NICOLE', 'SANDOVAL DUARTE', 'sandovalduarte.laura@ielibertadores.edu.co', 'A', '3112223344', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumn_team`
--

CREATE TABLE IF NOT EXISTS `alumn_team` (
`id` int(11) NOT NULL,
  `alumn_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=61 ;

--
-- Volcado de datos para la tabla `alumn_team`
--

INSERT INTO `alumn_team` (`id`, `alumn_id`, `team_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1),
(11, 11, 2),
(12, 12, 2),
(13, 13, 2),
(14, 14, 2),
(15, 15, 2),
(16, 16, 2),
(17, 17, 2),
(18, 18, 2),
(19, 19, 2),
(20, 20, 2),
(21, 21, 3),
(22, 22, 3),
(23, 23, 3),
(24, 24, 3),
(25, 25, 3),
(26, 26, 3),
(27, 27, 3),
(28, 28, 3),
(29, 29, 3),
(30, 30, 3),
(31, 31, 4),
(32, 32, 4),
(33, 33, 4),
(34, 34, 4),
(35, 35, 4),
(36, 36, 4),
(37, 37, 4),
(38, 38, 4),
(39, 39, 4),
(40, 40, 4),
(41, 41, 5),
(42, 42, 5),
(43, 43, 5),
(44, 44, 5),
(45, 45, 5),
(46, 46, 5),
(47, 47, 5),
(48, 48, 5),
(49, 49, 5),
(50, 50, 5),
(51, 51, 6),
(52, 52, 6),
(53, 53, 6),
(54, 54, 6),
(55, 55, 6),
(56, 56, 6),
(57, 57, 6),
(58, 58, 6),
(59, 59, 6),
(60, 60, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `assistance`
--

CREATE TABLE IF NOT EXISTS `assistance` (
`id` int(11) NOT NULL,
  `kind_id` int(11) DEFAULT NULL,
  `date_at` date NOT NULL,
  `alumn_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `assistance`
--

INSERT INTO `assistance` (`id`, `kind_id`, `date_at`, `alumn_id`, `team_id`) VALUES
(1, 3, '2024-11-02', 60, 6),
(2, 4, '2024-11-02', 59, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `block`
--

CREATE TABLE IF NOT EXISTS `block` (
`id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `team_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

CREATE TABLE IF NOT EXISTS `permiso` (
`idpermiso` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `permiso`
--

INSERT INTO `permiso` (`idpermiso`, `nombre`) VALUES
(1, 'Escritorio'),
(2, 'Grupos'),
(3, 'Acceso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `team`
--

CREATE TABLE IF NOT EXISTS `team` (
`idgrupo` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `favorito` tinyint(1) NOT NULL,
  `idusuario` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `team`
--

INSERT INTO `team` (`idgrupo`, `nombre`, `favorito`, `idusuario`) VALUES
(1, 'SEXTO DE SECUNDARIA', 1, 1),
(2, 'SEPTIMO DE SECUNDARIA', 1, 1),
(3, 'OCTAVO DE SECUNDARIA', 1, 1),
(4, 'NOVENO DE SECUNDARIA', 1, 1),
(5, 'DECIMO DE SECUNDARIA', 1, 1),
(6, 'UNDECIMO DE SECUNDARIA', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
`idusuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo_documento` varchar(20) NOT NULL,
  `num_documento` varchar(20) NOT NULL,
  `direccion` varchar(70) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `cargo` varchar(20) DEFAULT NULL,
  `login` varchar(20) NOT NULL,
  `clave` varchar(64) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  `condicion` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nombre`, `tipo_documento`, `num_documento`, `direccion`, `telefono`, `email`, `cargo`, `login`, `clave`, `imagen`, `condicion`) VALUES
(1, 'DEMO', 'DNI', '1022361475', 'Calle los alpes 210', '311223344', 'admin@gmail.com', 'Administrador', 'admin', 'admin', '1578849784.jpg', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_permiso`
--

CREATE TABLE IF NOT EXISTS `usuario_permiso` (
`idusuario_permiso` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idpermiso` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Volcado de datos para la tabla `usuario_permiso`
--

INSERT INTO `usuario_permiso` (`idusuario_permiso`, `idusuario`, `idpermiso`) VALUES
(7, 1, 1),
(8, 1, 2),
(9, 1, 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumn`
--
ALTER TABLE `alumn`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`) USING BTREE;

--
-- Indices de la tabla `alumn_team`
--
ALTER TABLE `alumn_team`
 ADD PRIMARY KEY (`id`), ADD KEY `alumn_id` (`alumn_id`), ADD KEY `team_id` (`team_id`);

--
-- Indices de la tabla `assistance`
--
ALTER TABLE `assistance`
 ADD PRIMARY KEY (`id`), ADD KEY `alumn_id` (`alumn_id`), ADD KEY `team_id` (`team_id`);

--
-- Indices de la tabla `block`
--
ALTER TABLE `block`
 ADD PRIMARY KEY (`id`), ADD KEY `team_id` (`team_id`);

--
-- Indices de la tabla `permiso`
--
ALTER TABLE `permiso`
 ADD PRIMARY KEY (`idpermiso`);

--
-- Indices de la tabla `team`
--
ALTER TABLE `team`
 ADD PRIMARY KEY (`idgrupo`), ADD KEY `team_ibfk_1` (`idusuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
 ADD PRIMARY KEY (`idusuario`), ADD UNIQUE KEY `login_UNIQUE` (`login`);

--
-- Indices de la tabla `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
 ADD PRIMARY KEY (`idusuario_permiso`), ADD KEY `fk_u_permiso_usuario_idx` (`idusuario`), ADD KEY `fk_usuario_permiso_idx` (`idpermiso`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumn`
--
ALTER TABLE `alumn`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT de la tabla `alumn_team`
--
ALTER TABLE `alumn_team`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT de la tabla `assistance`
--
ALTER TABLE `assistance`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `block`
--
ALTER TABLE `block`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `permiso`
--
ALTER TABLE `permiso`
MODIFY `idpermiso` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `team`
--
ALTER TABLE `team`
MODIFY `idgrupo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
MODIFY `idusuario_permiso` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumn`
--
ALTER TABLE `alumn`
ADD CONSTRAINT `alumn_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuario` (`idusuario`);

--
-- Filtros para la tabla `alumn_team`
--
ALTER TABLE `alumn_team`
ADD CONSTRAINT `alumn_team_ibfk_1` FOREIGN KEY (`alumn_id`) REFERENCES `alumn` (`id`),
ADD CONSTRAINT `alumn_team_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `team` (`idgrupo`);

--
-- Filtros para la tabla `assistance`
--
ALTER TABLE `assistance`
ADD CONSTRAINT `assistance_ibfk_1` FOREIGN KEY (`alumn_id`) REFERENCES `alumn` (`id`),
ADD CONSTRAINT `assistance_ibfk_2` FOREIGN KEY (`team_id`) REFERENCES `team` (`idgrupo`);

--
-- Filtros para la tabla `block`
--
ALTER TABLE `block`
ADD CONSTRAINT `block_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`idgrupo`);

--
-- Filtros para la tabla `team`
--
ALTER TABLE `team`
ADD CONSTRAINT `team_ibfk_1` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`);

--
-- Filtros para la tabla `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
ADD CONSTRAINT `fk_u_permiso_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_usuario_permiso` FOREIGN KEY (`idpermiso`) REFERENCES `permiso` (`idpermiso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
